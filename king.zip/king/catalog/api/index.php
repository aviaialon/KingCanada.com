<?php
require_once '../../wp-admin/Core/Application.php';

$allowedCalls = array(
	'Core\King\Products\Product_Wishlist::remove',
	'Core\King\Products\Product_Wishlist::add'
);

if (empty($_GET['path']) === true) exit;
preg_match('/(?P<mask>.*[^\/])/', $_GET['path'], $matched);
if (empty($matched['mask']) === true) die ('403 Forbidden');

\Core\Application::bootstrapResource('\Core\Crypt\AesCrypt');
$aesCrypto = \Core\Crypt\AesCrypt::getInstance();
$data      = @unserialize($aesCrypto->decrypt(base64_decode($matched['mask'])));

if (true === empty($data) || false === is_array($data)) {
	die ('403 Forbidden');	
}

$apiImplicitCall = $data['class'] . '::' . $data['method'];

if (false === in_array($apiImplicitCall, $allowedCalls)) {
	die ('403 Forbidden');	
}

\Core\Application::bootstrapResource('\\' . $data['class']);
$targetObject = call_user_func_array(array($data['class'], 'getInstance'), array());
if (false === headers_sent()) {
	header('Content-Type: application/json');	
}

$response = array(
	'success' 	=> call_user_func_array(array($targetObject, $data['method']), $data['params']), 
	'action' 	=> $data['method']
);

if (strcmp($data['class'], 'Core\King\Products\Product_Wishlist') === 0 && empty($data['params']['id']) === false) { 
	$wishList = \Core\King\Products\Product_Wishlist::getInstance();
	$response['rmvUrl']   = $wishList->getRemoveUrl((int) $data['params']['id']);
	$response['addUrl']   = $wishList->getAddUrl((int) $data['params']['id']);
	$response['isInList'] = (bool) $wishList->get((int) $data['params']['id']);
}

echo json_encode($response);